import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;

// --- In-memory waiting users (simple MVP; move to DB later) ---
const waiting = new Map(); // key => array of users

function keyFromPrefs(p) {
  // Bucket distance to keep queues simple (10/50/100+) and gender pref
  const distBucket = p.rangeKm <= 10 ? '10' : p.rangeKm <= 50 ? '50' : '100';
  const genderWanted = p.wantGender || 'any';
  return `${genderWanted}:${distBucket}`;
}

function haversineKm(a, b) {
  const R = 6371;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}

io.on('connection', (socket) => {
  socket.data.matchedWith = null;

  socket.on('set_prefs', (prefs) => {
    // store user prefs & location
    socket.data.prefs = {
      gender: prefs.gender || 'any',
      wantGender: prefs.wantGender || 'any',
      rangeKm: Math.max(10, Math.min(500, Number(prefs.rangeKm || 50))),
      loc: prefs.loc // {lat, lon}
    };
  });

  socket.on('find_partner', () => {
    const p = socket.data.prefs;
    if (!p || !p.loc) {
      socket.emit('error_msg', 'Location/prefs missing');
      return;
    }

    const k = keyFromPrefs(p);
    if (!waiting.has(k)) waiting.set(k, []);

    // try to find a partner in this queue with mutual prefs & distance
    const queue = waiting.get(k);
    let idx = -1;
    for (let i = 0; i < queue.length; i++) {
      const candidate = queue[i];
      // mutual gender OK?
      const ok1 = (p.wantGender === 'any' || candidate.gender === p.wantGender);
      const ok2 = (candidate.wantGender === 'any' || p.gender === candidate.wantGender);
      if (!ok1 || !ok2) continue;
      // within range of both
      const d1 = haversineKm(p.loc, candidate.loc);
      const d2 = d1; // symmetric
      if (d1 <= p.rangeKm && d2 <= candidate.rangeKm) { idx = i; break; }
    }

    if (idx === -1) {
      // add to queue
      queue.push({ id: socket.id, ...p });
      waiting.set(k, queue);
      socket.emit('queue_wait');
      return;
    }

    const partner = queue.splice(idx, 1)[0];
    waiting.set(k, queue);

    const roomId = `room_${socket.id}_${partner.id}`;
    socket.join(roomId);
    io.sockets.sockets.get(partner.id)?.join(roomId);

    // map sockets
    socket.data.matchedWith = partner.id;
    const partnerSock = io.sockets.sockets.get(partner.id);
    if (partnerSock) partnerSock.data.matchedWith = socket.id;

    io.to(roomId).emit('matched', { roomId });
  });

  socket.on('signal', ({ roomId, data }) => {
    socket.to(roomId).emit('signal', data);
  });

  socket.on('leave', ({ roomId }) => {
    socket.leave(roomId);
    socket.to(roomId).emit('peer_left');
  });

  socket.on('disconnect', () => {
    // remove from waiting queues
    for (const [k, queue] of waiting.entries()) {
      const newQ = queue.filter(u => u.id !== socket.id);
      waiting.set(k, newQ);
    }
    // notify partner if any
    const partnerId = socket.data.matchedWith;
    if (partnerId) {
      io.to(partnerId).emit('peer_left');
    }
  });
});

server.listen(PORT, () => console.log(`GiviChat server running on http://localhost:${PORT}`));
