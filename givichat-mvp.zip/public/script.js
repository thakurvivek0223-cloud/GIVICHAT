const socket = io();
let pc, localStream, roomId = null;

const el = (id) => document.getElementById(id);
const status = (t) => (el('status').textContent = t);

const servers = { iceServers: [{ urls: [ 'stun:stun.l.google.com:19302' ] }] };

el('rangeKm').addEventListener('input', (e) => {
  el('rangeValue').textContent = e.target.value;
});

async function getLocation() {
  // Try precise first (requires HTTPS in production)
  if (navigator.geolocation) {
    try {
      const pos = await new Promise((res, rej) => navigator.geolocation.getCurrentPosition(res, rej, { enableHighAccuracy:true, timeout:5000 }));
      return { lat: pos.coords.latitude, lon: pos.coords.longitude };
    } catch {}
  }
  // Fallback: IP based (free endpoint)
  try {
    const r = await fetch('https://ipapi.co/json/');
    const j = await r.json();
    return { lat: j.latitude, lon: j.longitude };
  } catch {
    return null;
  }
}

async function startLocal() {
  localStream = await navigator.mediaDevices.getUserMedia({ video:true, audio:true });
  el('localVideo').srcObject = localStream;
}

function createPC() {
  pc = new RTCPeerConnection(servers);
  localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
  pc.ontrack = (e) => { el('remoteVideo').srcObject = e.streams[0]; };
  pc.onicecandidate = (e) => {
    if (e.candidate) socket.emit('signal', { roomId, data: { type:'candidate', candidate: e.candidate } });
  };
}

async function startMatch() {
  status('Finding a nearby partner...');
  const prefs = {
    gender: el('gender').value,
    wantGender: el('wantGender').value,
    rangeKm: Number(el('rangeKm').value),
    loc: await getLocation()
  };
  if (!prefs.loc) { status('Location error. Please allow location.'); return; }
  socket.emit('set_prefs', prefs);
  socket.emit('find_partner');
}

async function makeOffer() {
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  socket.emit('signal', { roomId, data: { type:'offer', sdp: offer } });
}

socket.on('queue_wait', () => status('Waiting in queue...'));
socket.on('matched', async (payload) => {
  roomId = payload.roomId;
  status('Partner found! Connecting...');
  createPC();
  // The one who receives 'matched' first may create offer; both creating is fine if we gate by polite flag.
  await makeOffer();
  el('nextBtn').disabled = false;
  el('endBtn').disabled = false;
  el('reportBtn').disabled = false;
});

socket.on('signal', async (msg) => {
  if (!pc) return;
  if (msg.type === 'offer') {
    await pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
    const ans = await pc.createAnswer();
    await pc.setLocalDescription(ans);
    socket.emit('signal', { roomId, data: { type:'answer', sdp: ans } });
  } else if (msg.type === 'answer') {
    await pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
  } else if (msg.type === 'candidate' && msg.candidate) {
    try { await pc.addIceCandidate(new RTCIceCandidate(msg.candidate)); } catch {}
  }
});

socket.on('peer_left', () => {
  status('Partner left. Click Next to find another.');
  cleanup();
});

function cleanup() {
  if (pc) { pc.getSenders().forEach(s => s.track && s.track.stop()); pc.close(); pc = null; }
  // Do not stop localStream; keep preview running
  el('remoteVideo').srcObject = null;
}

el('startBtn').onclick = async () => {
  el('startBtn').disabled = true;
  await startLocal();
  await startMatch();
};

el('nextBtn').onclick = () => {
  if (roomId) socket.emit('leave', { roomId });
  cleanup();
  startMatch();
};

el('endBtn').onclick = () => {
  if (roomId) socket.emit('leave', { roomId });
  cleanup();
  el('nextBtn').disabled = true;
  el('endBtn').disabled = true;
  el('reportBtn').disabled = true;
  status('Ended. Click Start to chat again.');
  el('startBtn').disabled = false;
};

el('reportBtn').onclick = () => {
  alert('Reported. Thank you. (MVP: Implement server-side moderation later)');
};
