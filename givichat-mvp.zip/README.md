# GiviChat — Nearby Stranger Video Chat (MVP)

This is a free browser-based MVP using **Node + Express + Socket.IO + WebRTC**.
It serves the static frontend and handles matching + signaling on the same server.

## Run locally
```bash
npm install
npm start
# open http://localhost:3000 in two tabs/devices
```

> Allow camera/microphone in your browser.

## Deploy (free)
Use Render (Web Service):
- Build command: `npm install`
- Start command: `npm start`
- It will give you an HTTPS URL; open it and allow camera/mic.
